package com.modofiesta

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Bg = Color(0xFF080A12)
private val Panel = Color(0xFF141827)
private val Cyan = Color(0xFF20E8FF)
private val Magenta = Color(0xFFFF32C8)
private val Lime = Color(0xFFB6FF3B)
private val Muted = Color(0xFF9AA6BD)

data class Track(
    val uri: Uri,
    val name: String,
    val durationMs: Long = 0L,
    val bpm: Int? = null,
    val key: String? = null,
    val analyzing: Boolean = false
)

class MainActivity : ComponentActivity() {
    private lateinit var player: ExoPlayer
    private val tracks = mutableStateListOf<Track>()
    private var folderName by mutableStateOf("Ninguna carpeta seleccionada")
    private var currentIndex by mutableIntStateOf(-1)
    private var scanMessage by mutableStateOf("Cargá una carpeta para comenzar")
    private var isAnalyzing by mutableStateOf(false)

    private val folderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: SecurityException) {}
            folderName = DocumentFile.fromTreeUri(this, uri)?.name ?: "Carpeta seleccionada"
            scanFolder(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        player.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                currentIndex = player.currentMediaItemIndex
            }
        })
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Panel, primary = Cyan, secondary = Magenta)) {
                ModoFiestaHome(
                    folderName = folderName,
                    message = scanMessage,
                    tracks = tracks,
                    currentIndex = currentIndex,
                    player = player,
                    onChooseFolder = { folderPicker.launch(null) },
                    onPlayTrack = { playTrack(it) },
                    onAnalyze = { analyzeLibrary() }
                )
            }
        }
    }

    private fun scanFolder(treeUri: Uri) {
        scanMessage = "Buscando archivos de audio…"
        tracks.clear()
        currentIndex = -1
        player.stop()
        lifecycleScope.launch {
            val found = withContext(Dispatchers.IO) {
                val root = DocumentFile.fromTreeUri(this@MainActivity, treeUri)
                val output = mutableListOf<Track>()
                fun walk(dir: DocumentFile, depth: Int = 0) {
                    if (depth > 20) return
                    dir.listFiles().forEach { file ->
                        if (file.isDirectory) walk(file, depth + 1)
                        else if (file.isFile && isAudio(file)) output.add(Track(file.uri, file.name ?: "Audio sin nombre"))
                    }
                }
                if (root != null) runCatching { walk(root) }
                output
            }
            tracks.addAll(found.sortedBy { it.name.lowercase() })
            scanMessage = if (found.isEmpty()) "No se encontraron canciones compatibles" else "${found.size} canciones encontradas · Analizando BPM y tonalidad…"
            if (found.isNotEmpty()) {
                playTrack(0)
                analyzeLibrary()
            }
        }
    }

    private fun isAudio(file: DocumentFile): Boolean {
        val mime = file.type.orEmpty()
        val name = file.name.orEmpty().lowercase()
        return mime.startsWith("audio/") || listOf(".mp3", ".wav", ".m4a", ".aac", ".flac", ".ogg", ".opus").any { name.endsWith(it) }
    }

    private fun playTrack(index: Int) {
        if (index !in tracks.indices) return
        currentIndex = index
        player.setMediaItem(MediaItem.fromUri(tracks[index].uri))
        player.prepare()
        player.play()
    }

    private fun analyzeLibrary() {
        if (isAnalyzing || tracks.isEmpty()) return
        isAnalyzing = true
        scanMessage = "Analizando BPM y tonalidad…"
        lifecycleScope.launch {
            for (i in tracks.indices) {
                val original = tracks[i]
                tracks[i] = original.copy(analyzing = true)
                val result = withContext(Dispatchers.IO) {
                    runCatching { AudioAnalyzer.analyze(this@MainActivity, original.uri) }.getOrNull()
                }
                tracks[i] = original.copy(
                    bpm = result?.bpm,
                    key = result?.key,
                    durationMs = result?.durationMs ?: original.durationMs
                )
            }
            isAnalyzing = false
            scanMessage = "Análisis finalizado · ${tracks.size} canciones"
        }
    }

    override fun onDestroy() {
        if (::player.isInitialized) player.release()
        super.onDestroy()
    }
}

@Composable
private fun ModoFiestaHome(
    folderName: String,
    message: String,
    tracks: List<Track>,
    currentIndex: Int,
    player: ExoPlayer,
    onChooseFolder: () -> Unit,
    onPlayTrack: (Int) -> Unit,
    onAnalyze: () -> Unit
) {
    var partyMode by remember { mutableStateOf(false) }
    var samplerMode by remember { mutableStateOf("ONE SHOT") }
    var selectedPad by remember { mutableIntStateOf(-1) }
    var showTrackPicker by remember { mutableStateOf(false) }
    var playing by remember { mutableStateOf(false) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onPlaybackStateChanged(playbackState: Int) { duration = player.duration.coerceAtLeast(0L) }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }
    LaunchedEffect(player) {
        while (true) {
            position = player.currentPosition.coerceAtLeast(0L)
            duration = player.duration.coerceAtLeast(0L)
            delay(400)
        }
    }
    val current = tracks.getOrNull(currentIndex)

    Box(
        modifier = Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF11152A), Bg, Color(0xFF090B13))))
    ) {
        Column(
            modifier = Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(13.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 10.dp)) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("MODOFIESTA", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                    Text("INTELLIGENT DJ SYSTEM  •  DJ LUCAS QUINTANA", color = Muted, fontSize = 9.sp, letterSpacing = .7.sp)
                }
                Surface(color = Color(0xFF102B35), shape = RoundedCornerShape(10.dp), modifier = Modifier.border(1.dp, Cyan.copy(alpha = .65f), RoundedCornerShape(10.dp))) {
                    Text("LOCAL AI", color = Cyan, modifier = Modifier.padding(horizontal = 11.dp, vertical = 8.dp), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }

            Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().border(1.dp, Cyan.copy(alpha = .65f), RoundedCornerShape(18.dp))) {
                Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.MusicNote, contentDescription = null, tint = Cyan)
                        Spacer(Modifier.width(7.dp))
                        Text("REPRODUCTOR", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Black, letterSpacing = 1.2.sp)
                        Spacer(Modifier.weight(1f))
                        Text("DECK ÚNICO", color = Muted, fontSize = 9.sp)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(58.dp).background(Brush.linearGradient(listOf(Color(0xFF263A59), Color(0xFF32163F))), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.MusicNote, null, tint = Cyan, modifier = Modifier.size(30.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f).clickable { if (tracks.isNotEmpty()) showTrackPicker = true }) {
                            Text(current?.name ?: "Ninguna canción cargada", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(if (tracks.isEmpty()) folderName else "Tocá el título para elegir otra canción", color = Muted, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        IconButton(onClick = onChooseFolder) { Icon(Icons.Default.FolderOpen, contentDescription = "Elegir carpeta", tint = Cyan) }
                    }
                    Box(Modifier.fillMaxWidth().height(54.dp).background(Color(0xFF0A101D), RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) {
                        Row(horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.CenterVertically) {
                            repeat(50) { i ->
                                val h = (8 + ((i * 19 + 7) % 38)).dp
                                Box(Modifier.width(3.dp).height(h).background(if (i < 25) Cyan.copy(alpha = .8f) else Magenta.copy(alpha = .8f), RoundedCornerShape(2.dp)))
                            }
                        }
                    }
                    Slider(
                        value = if (duration > 0) position.toFloat().coerceIn(0f, duration.toFloat()) else 0f,
                        onValueChange = { if (duration > 0) player.seekTo(it.toLong()) },
                        valueRange = 0f..duration.coerceAtLeast(1L).toFloat(),
                        colors = SliderDefaults.colors(thumbColor = Cyan, activeTrackColor = Magenta, inactiveTrackColor = Color(0xFF343B50))
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(formatTime(position), color = Muted, fontSize = 9.sp)
                        Spacer(Modifier.weight(1f))
                        Text(formatTime(duration), color = Muted, fontSize = 9.sp)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Spacer(Modifier.weight(1f))
                        FilledTonalIconButton(
                            onClick = { if (playing) player.pause() else if (player.mediaItemCount > 0) player.play() else if (tracks.isNotEmpty()) onPlayTrack(0) },
                            colors = IconButtonDefaults.filledTonalIconButtonColors(containerColor = Color(0xFF123744), contentColor = Cyan),
                            modifier = Modifier.size(54.dp)
                        ) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(32.dp)) }
                        Spacer(Modifier.weight(1f))
                        OutlinedButton(onClick = onChooseFolder, colors = ButtonDefaults.outlinedButtonColors(contentColor = Cyan)) {
                            Icon(Icons.Default.FolderOpen, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("CARGAR MÚSICA", fontSize = 10.sp)
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        Metric("BPM", current?.bpm?.toString() ?: "--.-", Cyan)
                        Metric("TONALIDAD", current?.key ?: "--", Magenta)
                        Metric("ENERGÍA", "--", Lime)
                    }
                }
            }

            Surface(color = if (partyMode) Color(0xFF102B2B) else Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth().border(1.dp, if (partyMode) Lime else Magenta.copy(alpha = .65f), RoundedCornerShape(16.dp))) {
                Row(modifier = Modifier.fillMaxWidth().clickable { partyMode = !partyMode }.padding(horizontal = 15.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("MODO FIESTA", color = if (partyMode) Lime else Color.White, fontSize = 15.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                        Text(if (partyMode) "ACTIVADO · Auto DJ preparado" else "Activá el Auto DJ inteligente", color = if (partyMode) Lime else Muted, fontSize = 10.sp)
                    }
                    Switch(checked = partyMode, onCheckedChange = { partyMode = it }, colors = SwitchDefaults.colors(checkedThumbColor = Bg, checkedTrackColor = Lime, uncheckedThumbColor = Muted, uncheckedTrackColor = Color(0xFF343B50)))
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("SAMPLER", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Black, letterSpacing = 1.2.sp)
                    Spacer(Modifier.weight(1f))
                    listOf("ONE SHOT", "LOOP").forEach { mode ->
                        FilterChip(selected = samplerMode == mode, onClick = { samplerMode = mode }, label = { Text(mode, fontSize = 9.sp) }, colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFF173542), selectedLabelColor = Cyan))
                        Spacer(Modifier.width(5.dp))
                    }
                }
                val pads = listOf("AIR HORN" to Magenta, "VOICE FX" to Cyan, "IMPACT" to Lime, "PERC LOOP" to Color(0xFFFFB347))
                LazyVerticalGrid(columns = GridCells.Fixed(2), modifier = Modifier.height(174.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(pads.size) { index ->
                        val (label, color) = pads[index]
                        val active = selectedPad == index
                        Surface(color = if (active) color.copy(alpha = .28f) else color.copy(alpha = .10f), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().height(82.dp).border(1.dp, color.copy(alpha = if (active) 1f else .75f), RoundedCornerShape(14.dp)).clickable { selectedPad = if (active) -1 else index }) {
                            Column(Modifier.padding(horizontal = 12.dp, vertical = 9.dp), verticalArrangement = Arrangement.SpaceBetween) {
                                Text("PAD 0${index + 1}", color = color, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                Text(label, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Black)
                                Text(if (active) "SELECCIONADO" else "TOCAR PARA DISPARAR", color = Muted, fontSize = 7.sp)
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.weight(1f))
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 7.dp)) {
                Icon(Icons.Default.Settings, null, tint = Muted, modifier = Modifier.size(14.dp))
                Spacer(Modifier.width(6.dp))
                Text("MODOFIESTA 0.3.1 · DJ LUCAS QUINTANA", color = Muted, fontSize = 8.sp)
                Spacer(Modifier.weight(1f))
                Text("CYBERPUNK RGB", color = Cyan, fontSize = 8.sp)
            }
        }
    }

    if (showTrackPicker) {
        AlertDialog(
            onDismissRequest = { showTrackPicker = false },
            containerColor = Panel,
            title = { Text("BIBLIOTECA MUSICAL", color = Color.White) },
            text = {
                LazyColumn(Modifier.heightIn(max = 420.dp)) {
                    items(tracks) { track ->
                        val index = tracks.indexOf(track)
                        Column(Modifier.fillMaxWidth().clickable { onPlayTrack(index); showTrackPicker = false }.padding(vertical = 9.dp)) {
                            Text(track.name, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("${track.bpm?.let { "$it BPM" } ?: "BPM pendiente"} · ${track.key ?: "Tonalidad pendiente"}", color = Muted, fontSize = 11.sp)
                        }
                        Divider(color = Color(0xFF343B50))
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showTrackPicker = false }) { Text("CERRAR", color = Cyan) } }
        )
    }
}

@Composable
private fun Metric(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = Muted, fontSize = 8.sp)
        Text(value, color = color, fontSize = 17.sp, fontWeight = FontWeight.Bold)
    }
}

private fun formatTime(ms: Long): String {
    if (ms <= 0) return "00:00"
    val total = ms / 1000
    return "%02d:%02d".format(total / 60, total % 60)
}
