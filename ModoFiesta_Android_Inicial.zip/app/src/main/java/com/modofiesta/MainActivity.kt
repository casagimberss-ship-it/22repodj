package com.modofiesta

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Bg = Color(0xFF080A12)
private val Panel = Color(0xFF141827)
private val Cyan = Color(0xFF20E8FF)
private val Magenta = Color(0xFFFF32C8)
private val Lime = Color(0xFFB6FF3B)
private val Muted = Color(0xFF9AA6BD)

data class Track(
    val uri: Uri, val name: String, val durationMs: Long = 0L,
    val bpm: Int? = null, val key: String? = null, val energy: Int? = null,
    val analyzing: Boolean = false, val favorite: Boolean = false
) {
    val camelot: String? get() = key?.let { toCamelot(it) }
}

class MainActivity : ComponentActivity() {
    private lateinit var player: ExoPlayer
    private val tracks = mutableStateListOf<Track>()
    private var folderName by mutableStateOf("Ninguna carpeta seleccionada")
    private var currentIndex by mutableIntStateOf(-1)
    private var scanMessage by mutableStateOf("Cargá una carpeta para comenzar")
    private var isAnalyzing by mutableStateOf(false)
    private val prefs by lazy { getSharedPreferences("modofiesta_library", MODE_PRIVATE) }

    private val folderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: SecurityException) {}
            folderName = DocumentFile.fromTreeUri(this, uri)?.name ?: "Carpeta seleccionada"
            scanFolder(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        player.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) { currentIndex = player.currentMediaItemIndex }
        })
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Panel, primary = Cyan, secondary = Magenta)) {
                ModoFiestaHome(folderName, scanMessage, tracks, currentIndex, player,
                    onChooseFolder = { folderPicker.launch(null) },
                    onSelectTrack = { selectTrack(it) }, onPlaySelected = { if (player.mediaItemCount > 0) player.play() },
                    onAnalyze = { analyzeLibrary() }, onToggleFavorite = { toggleFavorite(it) },
                    onNext = { recommendNext() })
            }
        }
    }

    private fun scanFolder(treeUri: Uri) {
        scanMessage = "Buscando archivos de audio…"
        tracks.clear(); currentIndex = -1; player.stop(); player.clearMediaItems()
        lifecycleScope.launch {
            val found = withContext(Dispatchers.IO) {
                val root = DocumentFile.fromTreeUri(this@MainActivity, treeUri)
                val output = mutableListOf<Track>()
                fun walk(dir: DocumentFile, depth: Int = 0) {
                    if (depth > 20) return
                    runCatching { dir.listFiles().forEach { file ->
                        if (file.isDirectory) walk(file, depth + 1)
                        else if (file.isFile && isAudio(file)) output.add(Track(file.uri, file.name ?: "Audio sin nombre"))
                    } }
                }
                if (root != null) walk(root)
                output
            }
            val favorites = prefs.getStringSet("favorites", emptySet()) ?: emptySet()
            tracks.addAll(found.sortedBy { it.name.lowercase() }.map { track ->
                val saved = prefs.getString("analysis_${track.uri}", null)?.split("|")
                track.copy(
                    favorite = favorites.contains(track.uri.toString()),
                    bpm = saved?.getOrNull(0)?.toIntOrNull(),
                    key = saved?.getOrNull(1)?.takeIf { it.isNotBlank() },
                    energy = saved?.getOrNull(2)?.toIntOrNull(),
                    durationMs = saved?.getOrNull(3)?.toLongOrNull() ?: 0L
                )
            })
            scanMessage = if (found.isEmpty()) "No se encontraron canciones compatibles" else "${found.size} canciones cargadas · Listas para analizar"
            // Intencionalmente no se inicia la reproducción ni el análisis automático.
        }
    }

    private fun isAudio(file: DocumentFile): Boolean {
        val mime = file.type.orEmpty(); val name = file.name.orEmpty().lowercase()
        return mime.startsWith("audio/") || listOf(".mp3", ".wav", ".m4a", ".aac", ".flac", ".ogg", ".opus").any { name.endsWith(it) }
    }

    private fun selectTrack(index: Int) {
        if (index !in tracks.indices) return
        currentIndex = index
        player.setMediaItem(MediaItem.fromUri(tracks[index].uri))
        player.prepare()
        player.pause() // selección/carga sin autoplay
    }

    private fun toggleFavorite(index: Int) {
        if (index !in tracks.indices) return
        tracks[index] = tracks[index].copy(favorite = !tracks[index].favorite)
        prefs.edit().putStringSet("favorites", tracks.filter { it.favorite }.map { it.uri.toString() }.toSet()).apply()
    }

    private fun analyzeLibrary() {
        if (isAnalyzing || tracks.isEmpty()) return
        isAnalyzing = true; scanMessage = "Analizando BPM, tonalidad y energía…"
        lifecycleScope.launch {
            for (i in tracks.indices) {
                val original = tracks[i]
                tracks[i] = original.copy(analyzing = true)
                val result = withContext(Dispatchers.IO) { runCatching { AudioAnalyzer.analyze(this@MainActivity, original.uri) }.getOrNull() }
                val updated = original.copy(bpm = result?.bpm, key = result?.key, energy = result?.energy, durationMs = result?.durationMs ?: original.durationMs, analyzing = false)
                tracks[i] = updated
                prefs.edit().putString("analysis_${original.uri}", "${updated.bpm ?: ""}|${updated.key ?: ""}|${updated.energy ?: ""}|${updated.durationMs}").apply()
            }
            isAnalyzing = false
            scanMessage = "Análisis finalizado · ${tracks.size} pistas"
        }
    }

    private fun recommendNext() {
        if (tracks.isEmpty()) return
        val current = tracks.getOrNull(currentIndex)
        val candidates = tracks.indices.filter { it != currentIndex && tracks[it].bpm != null }
        val best = candidates.maxByOrNull { i ->
            val t = tracks[i]
            val bpmScore = if (current?.bpm != null && t.bpm != null) (100 - kotlin.math.abs(current.bpm - t.bpm) * 3).coerceAtLeast(0) else 0
            val keyScore = if (current?.camelot != null && current.camelot == t.camelot) 100 else if (current?.camelot != null && camelotCompatible(current.camelot!!, t.camelot)) 65 else 0
            bpmScore + keyScore + (t.energy ?: 0)
        }
        if (best != null) {
            scanMessage = "Sugerida: ${tracks[best].name} · ${tracks[best].bpm ?: "--"} BPM · ${tracks[best].camelot ?: "Camelot --"}. Seleccionala para cargarla."
        } else scanMessage = "Analizá la biblioteca para obtener sugerencias de Auto DJ."
    }

    override fun onDestroy() { if (::player.isInitialized) player.release(); super.onDestroy() }
}

@Composable
private fun ModoFiestaHome(
    folderName: String, message: String, tracks: List<Track>, currentIndex: Int, player: ExoPlayer,
    onChooseFolder: () -> Unit, onSelectTrack: (Int) -> Unit, onPlaySelected: () -> Unit,
    onAnalyze: () -> Unit, onToggleFavorite: (Int) -> Unit, onNext: () -> Unit
) {
    var partyMode by remember { mutableStateOf(false) }
    var samplerMode by remember { mutableStateOf("ONE SHOT") }
    var playing by remember { mutableStateOf(false) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var query by remember { mutableStateOf("") }
    var sort by remember { mutableStateOf("Nombre") }
    var favoritesOnly by remember { mutableStateOf(false) }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onPlaybackStateChanged(playbackState: Int) { duration = player.duration.coerceAtLeast(0L) }
        }
        player.addListener(listener); onDispose { player.removeListener(listener) }
    }
    LaunchedEffect(player) { while (true) { position = player.currentPosition.coerceAtLeast(0L); duration = player.duration.coerceAtLeast(0L); delay(400) } }
    val current = tracks.getOrNull(currentIndex)
    val visibleTracks = tracks.withIndex().filter { (_, t) -> (!favoritesOnly || t.favorite) && t.name.contains(query, true) }
        .let { list -> when (sort) { "BPM" -> list.sortedBy { it.value.bpm ?: Int.MAX_VALUE }; "Camelot" -> list.sortedBy { it.value.camelot ?: "ZZ" }; else -> list.sortedBy { it.value.name.lowercase() } } }

    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF11152A), Bg, Color(0xFF090B13)))).statusBarsPadding().padding(horizontal = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp, bottom = 7.dp)) {
            Column(Modifier.weight(1f)) {
                Text("MODOFIESTA", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                Text("INTELLIGENT DJ SYSTEM  •  DJ LUCAS QUINTANA", color = Muted, fontSize = 9.sp, letterSpacing = .5.sp)
            }
            Text("LOCAL AI", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.border(1.dp, Cyan.copy(alpha = .65f), RoundedCornerShape(9.dp)).padding(10.dp))
        }
        // Reproductor compacto: mantiene la identidad y reduce altura para dejar biblioteca visible.
        Surface(color = Panel, shape = RoundedCornerShape(17.dp), modifier = Modifier.fillMaxWidth().border(1.dp, Cyan.copy(alpha = .65f), RoundedCornerShape(17.dp))) {
            Column(Modifier.padding(horizontal = 13.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.MusicNote, null, tint = Cyan, modifier = Modifier.size(19.dp)); Spacer(Modifier.width(7.dp))
                    Text("REPRODUCTOR", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.weight(1f)); Text("DECK ÚNICO", color = Muted, fontSize = 9.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(43.dp).background(Brush.linearGradient(listOf(Color(0xFF263A59), Color(0xFF32163F))), RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.MusicNote, null, tint = Cyan, modifier = Modifier.size(25.dp)) }
                    Spacer(Modifier.width(9.dp))
                    Column(Modifier.weight(1f)) {
                        Text(current?.name ?: "Ninguna canción seleccionada", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(if (current == null) folderName else "Seleccionada · ${current.bpm ?: "--"} BPM · ${current.camelot ?: "Camelot --"}", color = Muted, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    IconButton(onClick = onChooseFolder, modifier = Modifier.size(38.dp)) { Icon(Icons.Default.FolderOpen, "Carpetas", tint = Cyan) }
                }
                Row(Modifier.fillMaxWidth().height(22.dp).background(Color(0xFF0A101D), RoundedCornerShape(7.dp)), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    repeat(40) { i -> Box(Modifier.padding(horizontal = 1.dp).width(2.dp).height((5 + ((i * 13 + 9) % 16)).dp).background(if (i < 20) Cyan.copy(alpha = .8f) else Magenta.copy(alpha = .8f), RoundedCornerShape(2.dp))) }
                }
                Slider(value = if (duration > 0) position.toFloat().coerceIn(0f, duration.toFloat()) else 0f, onValueChange = { if (duration > 0) player.seekTo(it.toLong()) }, valueRange = 0f..duration.coerceAtLeast(1L).toFloat(), modifier = Modifier.height(25.dp), colors = SliderDefaults.colors(thumbColor = Cyan, activeTrackColor = Magenta, inactiveTrackColor = Color(0xFF343B50)))
                Row { Text(formatTime(position), color = Muted, fontSize = 8.sp); Spacer(Modifier.weight(1f)); Text(formatTime(duration), color = Muted, fontSize = 8.sp) }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Spacer(Modifier.weight(1f))
                    FilledTonalIconButton(onClick = { if (playing) player.pause() else onPlaySelected() }, modifier = Modifier.size(42.dp), colors = IconButtonDefaults.filledTonalIconButtonColors(containerColor = Color(0xFF123744), contentColor = Cyan)) { Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, modifier = Modifier.size(25.dp)) }
                    IconButton(onClick = onNext, modifier = Modifier.size(38.dp)) { Icon(Icons.Default.SkipNext, null, tint = Cyan) }
                    Spacer(Modifier.weight(1f))
                    OutlinedButton(onClick = onChooseFolder, contentPadding = PaddingValues(horizontal = 11.dp, vertical = 5.dp), colors = ButtonDefaults.outlinedButtonColors(contentColor = Cyan)) { Icon(Icons.Default.FolderOpen, null, modifier = Modifier.size(14.dp)); Spacer(Modifier.width(4.dp)); Text("CARGAR MÚSICA", fontSize = 9.sp) }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    Metric("BPM", current?.bpm?.toString() ?: "--", Cyan)
                    Metric("TONALIDAD", current?.key ?: "--", Magenta)
                    Metric("ENERGÍA", current?.energy?.let { "$it/100" } ?: "--", Lime)
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 5.dp, bottom = 2.dp)) {
            Column(Modifier.weight(1f)) { Text("BIBLIOTECA MUSICAL", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Black); Text(message, color = Muted, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
            TextButton(onClick = onAnalyze, enabled = tracks.isNotEmpty()) { Text("ANALIZAR", color = Cyan, fontSize = 10.sp) }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Box(Modifier.weight(1f).background(Panel, RoundedCornerShape(8.dp)).padding(horizontal = 9.dp, vertical = 8.dp)) {
                if (query.isEmpty()) Text("Buscar canción…", color = Muted, fontSize = 10.sp)
                BasicTextField(query, { query = it }, singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 11.sp), modifier = Modifier.fillMaxWidth())
            }
            FilterChip(selected = favoritesOnly, onClick = { favoritesOnly = !favoritesOnly }, label = { Text("♥", fontSize = 11.sp) }, colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFF3A1735), selectedLabelColor = Magenta))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 3.dp)) {
            listOf("Nombre", "BPM", "Camelot").forEach { option -> FilterChip(selected = sort == option, onClick = { sort = option }, label = { Text(option, fontSize = 9.sp) }, colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFF173542), selectedLabelColor = Cyan)) }
            Text("${visibleTracks.size} pistas", color = Muted, fontSize = 9.sp)
        }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp), contentPadding = PaddingValues(bottom = 5.dp)) {
            items(visibleTracks, key = { it.value.uri.toString() }) { entry ->
                val index = entry.index; val track = entry.value; val selected = index == currentIndex
                Surface(color = if (selected) Color(0xFF12313B) else Panel, shape = RoundedCornerShape(10.dp), modifier = Modifier.fillMaxWidth().border(if (selected) 1.dp else 0.dp, if (selected) Cyan.copy(alpha = .7f) else Panel, RoundedCornerShape(10.dp))) {
                    Row(Modifier.clickable { onSelectTrack(index) }.padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.MusicNote, null, tint = if (selected) Cyan else Muted, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Text(track.name, color = Color.White, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(if (track.analyzing) "Analizando…" else "${track.bpm?.let { "$it BPM" } ?: "BPM --"}  ·  ${track.camelot ?: "Camelot --"}  ·  ${track.energy?.let { "Energía $it" } ?: "Energía --"}", color = Muted, fontSize = 8.sp)
                        }
                        IconButton(onClick = { onToggleFavorite(index) }, modifier = Modifier.size(32.dp)) { Icon(if (track.favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (track.favorite) Magenta else Muted, modifier = Modifier.size(17.dp)) }
                        Text(formatTime(track.durationMs), color = Cyan, fontSize = 8.sp)
                    }
                }
            }
        }
        // Auto DJ y sampler siguen debajo del listado en una sección compacta.
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 3.dp)) {
            Column(Modifier.weight(1f)) { Text("MODO FIESTA", color = Color.White, fontWeight = FontWeight.Black, fontSize = 13.sp); Text(if (partyMode) "Auto DJ activado · sugerencias manuales" else "Activá el Auto DJ inteligente", color = Muted, fontSize = 9.sp) }
            Switch(checked = partyMode, onCheckedChange = { partyMode = it }, colors = SwitchDefaults.colors(checkedThumbColor = Bg, checkedTrackColor = Lime))
        }
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 5.dp)) {
            Text("SAMPLER", color = Color.White, fontWeight = FontWeight.Black, fontSize = 12.sp)
            Spacer(Modifier.weight(1f))
            listOf("ONE SHOT", "LOOP").forEach { mode -> FilterChip(selected = samplerMode == mode, onClick = { samplerMode = mode }, label = { Text(mode, fontSize = 8.sp) }) }
            Text(" · 4 pads configurables", color = Muted, fontSize = 8.sp)
        }
    }
}

@Composable private fun Metric(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(label, color = Muted, fontSize = 8.sp); Text(value, color = color, fontSize = 15.sp, fontWeight = FontWeight.Bold) }
}
private fun formatTime(ms: Long): String { if (ms <= 0) return "00:00"; val total = ms / 1000; return "%02d:%02d".format(total / 60, total % 60) }

private fun toCamelot(raw: String): String? {
    val normalized = raw.trim().replace("♭", "b").replace("♯", "#")
    val map = mapOf("C maj" to "8B", "G maj" to "9B", "D maj" to "10B", "A maj" to "11B", "E maj" to "12B", "B maj" to "1B", "F# maj" to "2B", "Gb maj" to "2B", "C# maj" to "3B", "Db maj" to "3B", "G# maj" to "4B", "Ab maj" to "4B", "D# maj" to "5B", "Eb maj" to "5B", "A# maj" to "6B", "Bb maj" to "6B", "F maj" to "7B", "A min" to "8A", "E min" to "9A", "B min" to "10A", "F# min" to "11A", "C# min" to "12A", "G# min" to "1A", "D# min" to "2A", "A# min" to "3A", "F min" to "4A", "C min" to "5A", "G min" to "6A", "D min" to "7A")
    return map[normalized]
}
private fun camelotCompatible(a: String, b: String?): Boolean {
    if (b == null) return false
    val na = a.dropLast(1).toIntOrNull() ?: return false; val nb = b.dropLast(1).toIntOrNull() ?: return false
    return a.last() == b.last() && (na == nb || (na - nb + 12) % 12 == 1 || (nb - na + 12) % 12 == 1) || na == nb && a.last() != b.last()
}
