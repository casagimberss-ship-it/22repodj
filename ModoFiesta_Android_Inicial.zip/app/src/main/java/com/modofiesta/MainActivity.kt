package com.modofiesta

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Bg = Color(0xFF080A12)
private val Panel = Color(0xFF141827)
private val Cyan = Color(0xFF20E8FF)
private val Magenta = Color(0xFFFF32C8)
private val Lime = Color(0xFFB6FF3B)
private val Muted = Color(0xFF9AA6BD)

data class Track(
    val uri: Uri,
    val name: String,
    val durationMs: Long = 0L,
    val bpm: Int? = null,
    val key: String? = null,
    val analyzing: Boolean = false
)

class MainActivity : ComponentActivity() {
    private lateinit var player: ExoPlayer
    private val tracks = mutableStateListOf<Track>()
    private var selectedFolder by mutableStateOf("Ninguna carpeta seleccionada")
    private var currentIndex by mutableIntStateOf(-1)
    private var scanMessage by mutableStateOf("Seleccioná una carpeta para comenzar")
    private var isAnalyzing by mutableStateOf(false)

    private val folderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: SecurityException) {}
            selectedFolder = DocumentFile.fromTreeUri(this, uri)?.name ?: "Carpeta seleccionada"
            scanFolder(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        player.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                currentIndex = player.currentMediaItemIndex
            }
        })
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(background = Bg, surface = Panel, primary = Cyan, secondary = Magenta)) {
                ModoFiestaScreen(
                    folderName = selectedFolder,
                    message = scanMessage,
                    tracks = tracks,
                    currentIndex = currentIndex,
                    player = player,
                    onChooseFolder = { folderPicker.launch(null) },
                    onPlayTrack = { index -> playTrack(index) },
                    onAnalyze = { analyzeLibrary() }
                )
            }
        }
    }

    private fun scanFolder(treeUri: Uri) {
        scanMessage = "Buscando archivos de audio…"
        tracks.clear()
        lifecycleScope.launch {
            val found = withContext(Dispatchers.IO) {
                val root = DocumentFile.fromTreeUri(this@MainActivity, treeUri)
                val output = mutableListOf<Track>()
                fun walk(dir: DocumentFile) {
                    dir.listFiles().forEach { file ->
                        if (file.isDirectory) walk(file)
                        else if (file.isFile && isAudio(file)) {
                            output.add(Track(file.uri, file.name ?: "Audio sin nombre"))
                        }
                    }
                }
                if (root != null) walk(root)
                output
            }
            tracks.addAll(found.sortedBy { it.name.lowercase() })
            scanMessage = if (found.isEmpty()) "No se encontraron canciones compatibles" else "${found.size} canciones encontradas"
            if (found.isNotEmpty()) analyzeLibrary()
        }
    }

    private fun isAudio(file: DocumentFile): Boolean {
        val mime = file.type.orEmpty()
        val name = file.name.orEmpty().lowercase()
        return mime.startsWith("audio/") || listOf(".mp3", ".wav", ".m4a", ".aac", ".flac", ".ogg", ".opus").any { name.endsWith(it) }
    }

    private fun playTrack(index: Int) {
        if (index !in tracks.indices) return
        currentIndex = index
        player.setMediaItem(MediaItem.fromUri(tracks[index].uri))
        player.prepare()
        player.play()
    }

    private fun analyzeLibrary() {
        if (isAnalyzing) return
        isAnalyzing = true
        scanMessage = "Analizando BPM y tonalidad…"
        lifecycleScope.launch {
            for (i in tracks.indices) {
                val original = tracks[i]
                tracks[i] = original.copy(analyzing = true)
                val result = withContext(Dispatchers.IO) {
                    runCatching { AudioAnalyzer.analyze(this@MainActivity, original.uri) }.getOrNull()
                }
                tracks[i] = original.copy(bpm = result?.bpm, key = result?.key, durationMs = result?.durationMs ?: original.durationMs)
            }
            isAnalyzing = false
            scanMessage = "Análisis finalizado · ${tracks.size} canciones"
        }
    }

    override fun onDestroy() {
        player.release()
        super.onDestroy()
    }
}

@Composable
private fun ModoFiestaScreen(
    folderName: String,
    message: String,
    tracks: List<Track>,
    currentIndex: Int,
    player: ExoPlayer,
    onChooseFolder: () -> Unit,
    onPlayTrack: (Int) -> Unit,
    onAnalyze: () -> Unit
) {
    var playing by remember { mutableStateOf(false) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    val scope = rememberCoroutineScope()

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
            override fun onPlaybackStateChanged(playbackState: Int) {
                duration = player.duration.coerceAtLeast(0L)
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }
    LaunchedEffect(player) {
        while (true) {
            position = player.currentPosition.coerceAtLeast(0L)
            duration = player.duration.coerceAtLeast(0L)
            delay(400)
        }
    }

    val current = tracks.getOrNull(currentIndex)
    Column(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF11152A), Bg, Color(0xFF090B13)))).statusBarsPadding().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(Modifier.padding(top = 9.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("MODOFIESTA", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                Text("INTELLIGENT DJ SYSTEM  •  DJ LUCAS QUINTANA", color = Muted, fontSize = 9.sp)
            }
            Text("AUDIO ENGINE", color = Cyan, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }

        Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.MusicNote, null, tint = Cyan)
                    Spacer(Modifier.width(7.dp))
                    Text("REPRODUCTOR", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Black)
                    Spacer(Modifier.weight(1f))
                    Text("DECK ÚNICO", color = Muted, fontSize = 9.sp)
                }
                Text(current?.name ?: "Ninguna canción cargada", color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Slider(
                    value = if (duration > 0) position.toFloat().coerceIn(0f, duration.toFloat()) else 0f,
                    onValueChange = { if (duration > 0) player.seekTo(it.toLong()) },
                    valueRange = 0f..(duration.coerceAtLeast(1L).toFloat()),
                    colors = SliderDefaults.colors(thumbColor = Cyan, activeTrackColor = Magenta)
                )
                Row {
                    Text(formatTime(position), color = Muted, fontSize = 10.sp)
                    Spacer(Modifier.weight(1f))
                    Text(formatTime(duration), color = Muted, fontSize = 10.sp)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Spacer(Modifier.weight(1f))
                    FilledTonalIconButton(onClick = { if (playing) player.pause() else if (player.mediaItemCount > 0) player.play() else if (tracks.isNotEmpty()) onPlayTrack(0) }) {
                        Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Cyan)
                    }
                    IconButton(onClick = { if (tracks.isNotEmpty()) onPlayTrack(((currentIndex + 1).coerceAtLeast(0)) % tracks.size) }) {
                        Icon(Icons.Default.SkipNext, null, tint = Cyan)
                    }
                    Spacer(Modifier.weight(1f))
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    Metric("BPM", current?.bpm?.toString() ?: "--", Cyan)
                    Metric("TONALIDAD", current?.key ?: "--", Magenta)
                    Metric("PISTAS", tracks.size.toString(), Lime)
                }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(folderName, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(message, color = Muted, fontSize = 10.sp)
            }
            OutlinedButton(onClick = onChooseFolder) {
                Icon(Icons.Default.FolderOpen, null, tint = Cyan)
                Spacer(Modifier.width(4.dp))
                Text("CARPETAS", color = Cyan, fontSize = 10.sp)
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("BIBLIOTECA MUSICAL", color = Color.White, fontWeight = FontWeight.Black, fontSize = 13.sp)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = onAnalyze) { Text("ANALIZAR", color = Cyan, fontSize = 10.sp) }
        }
        if (tracks.isEmpty()) {
            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                Text("Cargá una carpeta para ver tus canciones", color = Muted)
            }
        } else {
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
                items(tracks.indices.toList()) { index ->
                    val track = tracks[index]
                    Surface(
                        color = if (index == currentIndex) Color(0xFF12313B) else Panel,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().clickable { onPlayTrack(index) }
                    ) {
                        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.MusicNote, null, tint = if (index == currentIndex) Cyan else Muted)
                            Spacer(Modifier.width(9.dp))
                            Column(Modifier.weight(1f)) {
                                Text(track.name, color = Color.White, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(
                                    if (track.analyzing) "Analizando…" else "${track.bpm?.let { "$it BPM" } ?: "BPM --"}  ·  ${track.key ?: "Tonalidad --"}",
                                    color = Muted, fontSize = 9.sp
                                )
                            }
                            Text(if (index == currentIndex && playing) "SONANDO" else formatTime(track.durationMs), color = Cyan, fontSize = 9.sp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Metric(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = Muted, fontSize = 8.sp)
        Text(value, color = color, fontSize = 16.sp, fontWeight = FontWeight.Bold)
    }
}

private fun formatTime(ms: Long): String {
    if (ms <= 0) return "00:00"
    val total = ms / 1000
    return "%02d:%02d".format(total / 60, total % 60)
}
