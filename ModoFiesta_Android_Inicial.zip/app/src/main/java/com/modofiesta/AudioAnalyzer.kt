package com.modofiesta

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

data class AnalysisResult(val bpm: Int?, val key: String?, val durationMs: Long)

/**
 * Lightweight offline analyzer. Decodes a short PCM sample, estimates tempo from
 * energy-envelope autocorrelation and key from chroma spectral energy.
 * Results are estimates, not studio-grade beat grids.
 */
object AudioAnalyzer {
    private val noteNames = arrayOf("C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B")
    private val major = doubleArrayOf(6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88)
    private val minor = doubleArrayOf(6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17)

    fun analyze(context: Context, uri: Uri): AnalysisResult {
        val pcm = decode(context, uri, 24)
        if (pcm.samples.size < 8000) return AnalysisResult(null, null, pcm.durationMs)
        return AnalysisResult(estimateBpm(pcm.samples, pcm.sampleRate), estimateKey(pcm.samples, pcm.sampleRate), pcm.durationMs)
    }

    private data class Pcm(val samples: FloatArray, val sampleRate: Int, val durationMs: Long)

    private fun decode(context: Context, uri: Uri, seconds: Int): Pcm {
        val extractor = MediaExtractor()
        extractor.setDataSource(context, uri, null)
        var track = -1
        var format: MediaFormat? = null
        for (i in 0 until extractor.trackCount) {
            val f = extractor.getTrackFormat(i)
            val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("audio/")) { track = i; format = f; break }
        }
        if (track < 0 || format == null) {
            extractor.release()
            return Pcm(FloatArray(0), 22050, 0)
        }
        extractor.selectTrack(track)
        val mime = format.getString(MediaFormat.KEY_MIME)!!
        val duration = if (format.containsKey(MediaFormat.KEY_DURATION)) format.getLong(MediaFormat.KEY_DURATION) / 1000 else 0L
        val codec = MediaCodec.createDecoderByType(mime)
        codec.configure(format, null, null, 0)
        codec.start()
        val info = MediaCodec.BufferInfo()
        val output = ArrayList<Float>(22050 * seconds)
        var inputDone = false
        var outputDone = false
        var sampleRate = if (format.containsKey(MediaFormat.KEY_SAMPLE_RATE)) format.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44100
        var channels = if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) format.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
        val limit = seconds * sampleRate
        try {
            while (!outputDone && output.size < limit) {
                if (!inputDone) {
                    val inputIndex = codec.dequeueInputBuffer(10000)
                    if (inputIndex >= 0) {
                        val buffer = codec.getInputBuffer(inputIndex)!!
                        val size = extractor.readSampleData(buffer, 0)
                        if (size < 0) {
                            codec.queueInputBuffer(inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(inputIndex, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                val outputIndex = codec.dequeueOutputBuffer(info, 10000)
                when {
                    outputIndex >= 0 -> {
                        val buffer = codec.getOutputBuffer(outputIndex)
                        if (buffer != null && info.size > 0) {
                            val outFormat = codec.outputFormat
                            if (outFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) sampleRate = outFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                            if (outFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = outFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                            buffer.position(info.offset)
                            buffer.limit(info.offset + info.size)
                            val pcmEncoding = if (outFormat.containsKey(MediaFormat.KEY_PCM_ENCODING)) outFormat.getInteger(MediaFormat.KEY_PCM_ENCODING) else 2
                            if (pcmEncoding == 2) {
                                while (buffer.remaining() >= 2 && output.size < limit) {
                                    var sum = 0f
                                    for (c in 0 until channels) {
                                        if (buffer.remaining() < 2) break
                                        sum += buffer.short.toFloat() / 32768f
                                    }
                                    output.add(sum / channels.coerceAtLeast(1))
                                }
                            }
                        }
                        outputDone = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                        codec.releaseOutputBuffer(outputIndex, false)
                    }
                    outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val f = codec.outputFormat
                        if (f.containsKey(MediaFormat.KEY_SAMPLE_RATE)) sampleRate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        if (f.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    }
                }
            }
        } finally {
            runCatching { codec.stop() }
            codec.release()
            extractor.release()
        }
        return Pcm(output.toFloatArray(), sampleRate, duration)
    }

    private fun estimateBpm(samples: FloatArray, sampleRate: Int): Int? {
        val window = max(1, sampleRate / 100)
        val envelope = ArrayList<Double>()
        var i = 0
        while (i + window < samples.size) {
            var energy = 0.0
            for (j in i until i + window) energy += samples[j] * samples[j]
            envelope.add(sqrt(energy / window))
            i += window
        }
        if (envelope.size < 300) return null
        val minLag = 6000 / 180
        val maxLag = 6000 / 60
        var bestLag = 0
        var best = Double.NEGATIVE_INFINITY
        for (lag in minLag..maxLag) {
            var corr = 0.0
            var count = 0
            for (n in lag until envelope.size) {
                corr += (envelope[n] - envelope[n - lag]) * (envelope[n - lag])
                count++
            }
            if (count > 0 && corr / count > best) { best = corr / count; bestLag = lag }
        }
        if (bestLag == 0) return null
        var bpm = (6000.0 / bestLag).toInt()
        while (bpm < 70) bpm *= 2
        while (bpm > 180) bpm /= 2
        return bpm.takeIf { it in 60..200 }
    }

    private fun estimateKey(samples: FloatArray, sampleRate: Int): String? {
        val size = 4096
        val stride = 2048
        val chroma = DoubleArray(12)
        var frames = 0
        var start = 0
        while (start + size < samples.size && frames < 100) {
            val real = DoubleArray(size)
            for (n in 0 until size) {
                val window = 0.5 - 0.5 * cos(2.0 * PI * n / (size - 1))
                real[n] = samples[start + n] * window
            }
            // Direct spectral energy at equal-tempered note frequencies across octaves.
            for (note in 0..11) {
                for (octave in 2..6) {
                    val freq = 440.0 * 2.0.pow((note - 9 + (octave - 4) * 12) / 12.0)
                    if (freq < 45 || freq >= sampleRate / 2.0) continue
                    chroma[note] += goertzel(real, sampleRate, freq)
                }
            }
            frames++
            start += stride
        }
        if (frames == 0) return null
        val norm = sqrt(chroma.sumOf { it * it })
        if (norm <= 1e-12) return null
        val c = DoubleArray(12) { chroma[it] / norm }
        var bestName: String? = null
        var bestScore = Double.NEGATIVE_INFINITY
        for (root in 0..11) {
            for ((mode, profile) in listOf("Major" to major, "Minor" to minor)) {
                var score = 0.0
                for (n in 0..11) score += c[(n + root) % 12] * profile[n]
                if (score > bestScore) {
                    bestScore = score
                    bestName = noteNames[root] + if (mode == "Major") " maj" else " min"
                }
            }
        }
        return bestName
    }

    private fun goertzel(x: DoubleArray, sampleRate: Int, frequency: Double): Double {
        val k = (0.5 + x.size * frequency / sampleRate).toInt()
        val omega = 2.0 * PI * k / x.size
        val coeff = 2.0 * cos(omega)
        var q1 = 0.0
        var q2 = 0.0
        for (v in x) {
            val q0 = coeff * q1 - q2 + v
            q2 = q1
            q1 = q0
        }
        return max(0.0, q1 * q1 + q2 * q2 - coeff * q1 * q2)
    }
}
