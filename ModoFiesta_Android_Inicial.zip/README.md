# ModoFiesta 0.3.0 – DJ Lucas Quintana

## Funciones incorporadas en esta etapa
- Selección de carpeta mediante Android Storage Access Framework.
- Escaneo recursivo de archivos de audio en la carpeta y subcarpetas.
- Biblioteca local de pistas.
- Reproducción y pausa con AndroidX Media3 / ExoPlayer.
- Barra de progreso y salto de pista.
- Análisis offline aproximado de BPM por autocorrelación de envolvente.
- Estimación de tonalidad por energía cromática espectral.
- Formatos habituales: MP3, WAV, M4A, AAC, FLAC, OGG y OPUS, sujetos a los decodificadores disponibles en el dispositivo.

## Notas sobre el análisis
BPM y tonalidad son estimaciones calculadas localmente sobre una muestra inicial del audio. No son beatgrid profesional ni garantizan precisión en pistas con intros silenciosas, percusión irregular, cambios de tempo o armonías complejas. Los resultados pueden variar según el archivo y el decodificador del dispositivo.

## Compilación
JDK 17, Android SDK 35 y Gradle 8.9:
`gradle --no-daemon clean assembleDebug`

## Estado
La reproducción y el escaneo se conectan al motor Media3. El análisis se ejecuta localmente. Auto DJ, sampler, grabación MP3 y mezcla entre pistas todavía no están implementados en esta etapa.
