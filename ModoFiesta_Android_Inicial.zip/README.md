# ModoFiesta 0.3.2 – Biblioteca y análisis local

## Incluido
- Interfaz cyberpunk RGB conservada, con reproductor compacto y biblioteca visible.
- Escaneo recursivo de carpetas de audio.
- Cargar carpeta no inicia reproducción ni análisis automáticamente.
- Seleccionar una pista la prepara en pausa; solo Play inicia el audio.
- Búsqueda, orden por nombre/BPM/Camelot y filtro de favoritos.
- Favoritos y resultados BPM/tonalidad/energía guardados localmente.
- Análisis offline aproximado de BPM, tonalidad y energía RMS.
- Conversión de tonalidad estimada a rueda Camelot.
- Auto DJ calcula una sugerencia por proximidad de BPM y compatibilidad Camelot; la selección sigue siendo manual.

## Limitaciones conocidas
- BPM y tonalidad son estimaciones sobre una muestra inicial; deben validarse con música real.
- Energía es un indicador RMS relativo, no una clasificación musical avanzada.
- Playlists personalizadas, detección fiable de intro/outro y frases, waveform real, carga/reproducción de pads, efectos DSP y mezcla/transiciones automáticas quedan para etapas posteriores.
- Auto DJ recomienda; no mezcla ni cambia automáticamente de pista.
- Los pads conservan su apariencia, pero todavía no disparan audio.

## Compilación
JDK 17, Android SDK 35 y Gradle 8.9: `gradle --no-daemon clean assembleDebug`
