# ModoFiesta – Android

**Created by DJ Lucas Quintana**

Base inicial Android para ModoFiesta, con interfaz Cyberpunk RGB, selección persistente de carpeta mediante Storage Access Framework, pantallas Mixer/Library/Sampler y workflow de GitHub Actions para generar una APK Debug.

## Requisitos
- Android Studio reciente
- JDK 17
- Android SDK Platform 35
- Gradle 8.9 (el workflow de GitHub lo instala automáticamente)

## Compilar en GitHub
1. Crear un repositorio llamado `ModoFiesta`.
2. Subir el contenido de este ZIP a la raíz del repositorio.
3. Abrir la pestaña **Actions**.
4. Ejecutar **ModoFiesta Android APK** o hacer push a `main`.
5. Descargar el artefacto `ModoFiesta-debug-apk` al finalizar el workflow.

## Compilar localmente
Con Gradle 8.9 instalado:
```bash
gradle assembleDebug
```
APK: `app/build/outputs/apk/debug/app-debug.apk`

## Estado real de esta entrega
Esta es la **base visual y estructural 0.1.0**, no un DJ mixer terminado. La selección de carpeta funciona y conserva el permiso de lectura. Los decks, waveforms, crossfader, Auto DJ y pads son actualmente la interfaz inicial; todavía no reproducen ni mezclan audio. Los siguientes hitos son implementar el escaneo de archivos, análisis musical y motor de audio de dos decks.

## Próximos módulos
- Biblioteca local y metadatos
- BPM, tonalidad Camelot y energía
- Motor de audio dual con DSP
- Sincronización y efectos
- Auto DJ con planificador de transiciones
- Sampler real de cuatro pads
