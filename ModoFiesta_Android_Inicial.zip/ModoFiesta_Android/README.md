# ModoFiesta – Android

**Created by DJ Lucas Quintana**

Base Android Kotlin/Jetpack Compose con interfaz Cyberpunk RGB.

## Pantalla principal 0.2.0
- Un único reproductor principal.
- Selector de carpeta musical mediante Storage Access Framework.
- Debajo del reproductor: interruptor **MODO FIESTA** para activar/desactivar el modo Auto DJ.
- Debajo: cuatro pads de sampler (AIR HORN, VOICE FX, IMPACT y PERC LOOP).
- Selector visual de modo ONE SHOT / LOOP.

## Compilar
Requiere JDK 17, Android SDK Platform 35 y Gradle 8.9.

```bash
gradle assembleDebug
```

## Estado de esta entrega
Esta versión actualiza la distribución visual y la interacción básica de la pantalla. La selección de carpeta conserva permiso de lectura. El reproductor, el modo Auto DJ y los pads todavía son controles de interfaz: no reproducen audio ni ejecutan mezclas reales. Esos módulos se implementarán después con el motor de audio y el analizador musical.
