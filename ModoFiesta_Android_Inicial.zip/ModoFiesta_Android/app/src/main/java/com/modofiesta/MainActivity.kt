package com.modofiesta

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF080A12)
private val Panel = Color(0xFF141827)
private val Cyan = Color(0xFF20E8FF)
private val Magenta = Color(0xFFFF32C8)
private val Lime = Color(0xFFB6FF3B)
private val Muted = Color(0xFF9AA6BD)

class MainActivity : ComponentActivity() {
    private var folderName by mutableStateOf("Ninguna carpeta seleccionada")

    private val folderPicker = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri: Uri? ->
        uri?.let {
            contentResolver.takePersistableUriPermission(
                it, Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
            folderName = it.lastPathSegment?.substringAfterLast(':') ?: "Carpeta musical seleccionada"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    background = Bg,
                    surface = Panel,
                    primary = Cyan,
                    secondary = Magenta
                )
            ) {
                ModoFiestaHome(
                    folderName = folderName,
                    onChooseFolder = { folderPicker.launch(null) }
                )
            }
        }
    }
}

@Composable
private fun ModoFiestaHome(folderName: String, onChooseFolder: () -> Unit) {
    var autoDj by remember { mutableStateOf(false) }
    var selectedTab by remember { mutableStateOf("MIXER") }
    var samplerMode by remember { mutableStateOf("ONE SHOT") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF11152A), Bg, Color(0xFF090B13))))
    ) {
        Column(
            modifier = Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 10.dp)) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("MODO", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                    Text("FIESTA", color = Cyan, fontSize = 27.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                    Text("INTELLIGENT DJ SYSTEM  •  DJ LUCAS QUINTANA", color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
                }
                Surface(color = Color(0xFF102B35), shape = RoundedCornerShape(12.dp), modifier = Modifier.border(1.dp, Cyan.copy(alpha = .6f), RoundedCornerShape(12.dp))) {
                    Text("LOCAL AI", color = Cyan, modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("MIXER", "LIBRARY", "SAMPLER").forEach { tab ->
                    val active = selectedTab == tab
                    Surface(
                        color = if (active) Color(0xFF15313D) else Panel,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f).border(1.dp, if (active) Cyan else Color(0xFF293047), RoundedCornerShape(10.dp)).clickable { selectedTab = tab }
                    ) {
                        Text(tab, color = if (active) Cyan else Muted, modifier = Modifier.padding(vertical = 12.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    }
                }
            }

            when (selectedTab) {
                "LIBRARY" -> LibraryPanel(folderName, onChooseFolder)
                "SAMPLER" -> SamplerPanel(samplerMode) { samplerMode = it }
                else -> {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        DeckCard("DECK A", "TRACK A", "128.0", "8A", Cyan, Modifier.weight(1f))
                        DeckCard("DECK B", "TRACK B", "--.-", "--", Magenta, Modifier.weight(1f))
                    }
                    Surface(color = Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth().border(1.dp, Color(0xFF30384D), RoundedCornerShape(16.dp))) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.GraphicEq, null, tint = Cyan)
                                Text("AUTO DJ ENGINE", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                Switch(checked = autoDj, onCheckedChange = { autoDj = it }, colors = SwitchDefaults.colors(checkedThumbColor = Cyan, checkedTrackColor = Color(0xFF14515B)))
                            }
                            Text(if (autoDj) "AUTO DJ activado · esperando biblioteca y análisis" else "Auto DJ desactivado · control manual", color = if (autoDj) Lime else Muted, fontSize = 11.sp)
                            Text("PRÓXIMA TRANSICIÓN", color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
                            Text("Phrase Mixing  →  EQ Blend", color = Cyan, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                            Text("La selección automática estará disponible cuando se integre el motor de análisis musical.", color = Muted, fontSize = 10.sp)
                        }
                    }
                    Surface(color = Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(14.dp)) {
                            Text("MIX CONTROL", color = Color.White, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(12.dp))
                            Text("CROSSFADER", color = Muted, fontSize = 9.sp)
                            var cross by remember { mutableFloatStateOf(0f) }
                            Slider(value = cross, onValueChange = { cross = it }, valueRange = -1f..1f, colors = SliderDefaults.colors(thumbColor = Cyan, activeTrackColor = Magenta))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("DECK A", color = Cyan, fontSize = 9.sp)
                                Text("DECK B", color = Magenta, fontSize = 9.sp)
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.weight(1f))
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 8.dp)) {
                Icon(Icons.Default.Settings, null, tint = Muted, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("MODOFIESTA 0.1.0 · BASE DE DESARROLLO", color = Muted, fontSize = 9.sp)
            }
        }
    }
}

@Composable
private fun DeckCard(name: String, track: String, bpm: String, key: String, accent: Color, modifier: Modifier = Modifier) {
    Surface(color = Panel, shape = RoundedCornerShape(16.dp), modifier = modifier.border(1.dp, accent.copy(alpha = .55f), RoundedCornerShape(16.dp))) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text(name, color = accent, fontSize = 11.sp, fontWeight = FontWeight.Black)
            Text(track, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Box(Modifier.fillMaxWidth().height(42.dp).background(Color(0xFF0B101C), RoundedCornerShape(8.dp)), contentAlignment = Alignment.Center) {
                Row(horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.CenterVertically) {
                    repeat(24) { i ->
                        Box(Modifier.width(3.dp).height((8 + ((i * 17) % 29)).dp).background(accent.copy(alpha = .45f + (i % 3) * .15f), RoundedCornerShape(2.dp)))
                    }
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("BPM", color = Muted, fontSize = 8.sp)
                    Text(bpm, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("KEY", color = Muted, fontSize = 8.sp)
                    Text(key, color = accent, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
            }
            Text("PLAY  ·  CUE  ·  SYNC", color = Muted, fontSize = 8.sp)
        }
    }
}

@Composable
private fun LibraryPanel(folderName: String, onChooseFolder: () -> Unit) {
    Surface(color = Panel, shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("MUSIC LIBRARY", color = Color.White, fontWeight = FontWeight.Bold)
            Text("Seleccioná una carpeta de música del dispositivo. El acceso se conserva para próximas sesiones.", color = Muted, fontSize = 12.sp)
            OutlinedButton(onClick = onChooseFolder, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.outlinedButtonColors(contentColor = Cyan)) {
                Icon(Icons.Default.FolderOpen, null)
                Spacer(Modifier.width(8.dp))
                Text("SELECCIONAR CARPETA")
            }
            Text(folderName, color = Lime, fontSize = 11.sp)
            Text("El escaneo, la lectura de metadatos y el análisis BPM se incorporarán en la siguiente etapa.", color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun SamplerPanel(mode: String, onModeChange: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("PERFORMANCE SAMPLER", color = Color.White, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("ONE SHOT", "LOOP").forEach {
                FilterChip(selected = mode == it, onClick = { onModeChange(it) }, label = { Text(it) })
            }
        }
        val pads = listOf("AIR HORN" to Magenta, "VOICE FX" to Cyan, "IMPACT" to Lime, "PERC LOOP" to Color(0xFFFFB347))
        LazyVerticalGrid(columns = GridCells.Fixed(2), modifier = Modifier.height(250.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(pads.size) { index ->
                val (label, color) = pads[index]
                Surface(color = color.copy(alpha = .12f), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth().height(112.dp).border(1.dp, color, RoundedCornerShape(16.dp)).clickable { }) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.SpaceBetween) {
                        Text("PAD 0${index + 1}", color = color, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text(label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Black)
                        Text("ASIGNAR AUDIO", color = Muted, fontSize = 8.sp)
                    }
                }
            }
        }
        Text("Pads visuales iniciales. La reproducción y carga de muestras se implementarán en el módulo de audio.", color = Muted, fontSize = 10.sp)
    }
}
