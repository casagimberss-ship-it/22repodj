package com.modofiesta

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF080A12)
private val Panel = Color(0xFF141827)
private val Cyan = Color(0xFF20E8FF)
private val Magenta = Color(0xFFFF32C8)
private val Lime = Color(0xFFB6FF3B)
private val Muted = Color(0xFF9AA6BD)

class MainActivity : ComponentActivity() {
    private var folderName by mutableStateOf("Ninguna carpeta seleccionada")

    private val folderPicker = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri: Uri? ->
        uri?.let {
            contentResolver.takePersistableUriPermission(
                it, Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
            folderName = it.lastPathSegment?.substringAfterLast(':') ?: "Carpeta musical seleccionada"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    background = Bg,
                    surface = Panel,
                    primary = Cyan,
                    secondary = Magenta
                )
            ) {
                ModoFiestaHome(
                    folderName = folderName,
                    onChooseFolder = { folderPicker.launch(null) }
                )
            }
        }
    }
}

@Composable
private fun ModoFiestaHome(folderName: String, onChooseFolder: () -> Unit) {
    var partyMode by remember { mutableStateOf(false) }
    var isPlaying by remember { mutableStateOf(false) }
    var samplerMode by remember { mutableStateOf("ONE SHOT") }
    var selectedPad by remember { mutableIntStateOf(-1) }
    var trackPosition by remember { mutableFloatStateOf(0f) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF11152A), Bg, Color(0xFF090B13))))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(13.dp)
        ) {
            // Encabezado compacto
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(top = 10.dp)
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("MODOFIESTA", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                    Text("INTELLIGENT DJ SYSTEM  •  DJ LUCAS QUINTANA", color = Muted, fontSize = 9.sp, letterSpacing = .7.sp)
                }
                Surface(
                    color = Color(0xFF102B35),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.border(1.dp, Cyan.copy(alpha = .65f), RoundedCornerShape(10.dp))
                ) {
                    Text("LOCAL AI", color = Cyan, modifier = Modifier.padding(horizontal = 11.dp, vertical = 8.dp), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Un solo reproductor principal
            Surface(
                color = Panel,
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, Cyan.copy(alpha = .65f), RoundedCornerShape(18.dp))
            ) {
                Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.MusicNote, contentDescription = null, tint = Cyan)
                        Spacer(Modifier.width(7.dp))
                        Text("REPRODUCTOR", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Black, letterSpacing = 1.2.sp)
                        Spacer(Modifier.weight(1f))
                        Text("DECK ÚNICO", color = Muted, fontSize = 9.sp)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier.size(58.dp).background(
                                Brush.linearGradient(listOf(Color(0xFF263A59), Color(0xFF32163F))),
                                RoundedCornerShape(12.dp)
                            ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.MusicNote, null, tint = Cyan, modifier = Modifier.size(30.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Ninguna canción cargada", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                            Text(folderName, color = Muted, fontSize = 9.sp, maxLines = 1)
                        }
                        IconButton(onClick = onChooseFolder) {
                            Icon(Icons.Default.FolderOpen, contentDescription = "Elegir carpeta", tint = Cyan)
                        }
                    }
                    // Waveform decorativa de la maqueta
                    Box(
                        Modifier.fillMaxWidth().height(54.dp)
                            .background(Color(0xFF0A101D), RoundedCornerShape(10.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Row(horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.CenterVertically) {
                            repeat( fiftyBars ) { i ->
                                val h = (8 + ((i * 19 + 7) % 38)).dp
                                Box(Modifier.width(3.dp).height(h).background(if (i < 25) Cyan.copy(alpha = .8f) else Magenta.copy(alpha = .8f), RoundedCornerShape(2.dp)))
                            }
                        }
                    }
                    Slider(
                        value = trackPosition,
                        onValueChange = { trackPosition = it },
                        valueRange = 0f..1f,
                        colors = SliderDefaults.colors(thumbColor = Cyan, activeTrackColor = Magenta, inactiveTrackColor = Color(0xFF343B50))
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("00:00", color = Muted, fontSize = 9.sp)
                        Spacer(Modifier.weight(1f))
                        Text("00:00", color = Muted, fontSize = 9.sp)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Spacer(Modifier.weight(1f))
                        FilledTonalIconButton(
                            onClick = { isPlaying = !isPlaying },
                            colors = IconButtonDefaults.filledTonalIconButtonColors(containerColor = Color(0xFF123744), contentColor = Cyan),
                            modifier = Modifier.size(54.dp)
                        ) {
                            Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = if (isPlaying) "Pausar" else "Reproducir", modifier = Modifier.size(32.dp))
                        }
                        Spacer(Modifier.weight(1f))
                        OutlinedButton(onClick = onChooseFolder, colors = ButtonDefaults.outlinedButtonColors(contentColor = Cyan)) {
                            Icon(Icons.Default.FolderOpen, null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("CARGAR MÚSICA", fontSize = 10.sp)
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        Metric("BPM", "--.-", Cyan)
                        Metric("TONALIDAD", "--", Magenta)
                        Metric("ENERGÍA", "--", Lime)
                    }
                }
            }

            // Activación del modo fiesta debajo del reproductor
            Surface(
                color = if (partyMode) Color(0xFF102B2B) else Panel,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, if (partyMode) Lime else Magenta.copy(alpha = .65f), RoundedCornerShape(16.dp))
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().clickable { partyMode = !partyMode }.padding(horizontal = 15.dp, vertical = 13.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("MODO FIESTA", color = if (partyMode) Lime else Color.White, fontSize = 15.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                        Text(
                            if (partyMode) "ACTIVADO · Auto DJ preparado" else "Activá el Auto DJ inteligente",
                            color = if (partyMode) Lime else Muted,
                            fontSize = 10.sp
                        )
                    }
                    Switch(
                        checked = partyMode,
                        onCheckedChange = { partyMode = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = Bg, checkedTrackColor = Lime, uncheckedThumbColor = Muted, uncheckedTrackColor = Color(0xFF343B50))
                    )
                }
            }

            // Pads de sampler visibles debajo del modo fiesta
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("SAMPLER", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Black, letterSpacing = 1.2.sp)
                    Spacer(Modifier.weight(1f))
                    listOf("ONE SHOT", "LOOP").forEach { mode ->
                        FilterChip(
                            selected = samplerMode == mode,
                            onClick = { samplerMode = mode },
                            label = { Text(mode, fontSize = 9.sp) },
                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color(0xFF173542), selectedLabelColor = Cyan)
                        )
                        Spacer(Modifier.width(5.dp))
                    }
                }
                val pads = listOf("AIR HORN" to Magenta, "VOICE FX" to Cyan, "IMPACT" to Lime, "PERC LOOP" to Color(0xFFFFB347))
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    modifier = Modifier.height(174.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(pads.size) { index ->
                        val (label, color) = pads[index]
                        val active = selectedPad == index
                        Surface(
                            color = if (active) color.copy(alpha = .28f) else color.copy(alpha = .10f),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth().height(82.dp)
                                .border(1.dp, color.copy(alpha = if (active) 1f else .75f), RoundedCornerShape(14.dp))
                                .clickable { selectedPad = if (active) -1 else index }
                        ) {
                            Column(Modifier.padding(horizontal = 12.dp, vertical = 9.dp), verticalArrangement = Arrangement.SpaceBetween) {
                                Text("PAD 0${index + 1}", color = color, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                Text(label, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Black)
                                Text(if (active) "SELECCIONADO" else "TOCAR PARA DISPARAR", color = Muted, fontSize = 7.sp)
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.weight(1f))
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 7.dp)) {
                Icon(Icons.Default.Settings, null, tint = Muted, modifier = Modifier.size(14.dp))
                Spacer(Modifier.width(6.dp))
                Text("MODOFIESTA 0.2.0 · DJ LUCAS QUINTANA", color = Muted, fontSize = 8.sp)
                Spacer(Modifier.weight(1f))
                Text("CYBERPUNK RGB", color = Cyan, fontSize = 8.sp)
            }
        }
    }
}

private const val fiftyBars = 50

@Composable
private fun Metric(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = Muted, fontSize = 8.sp)
        Text(value, color = color, fontSize = 17.sp, fontWeight = FontWeight.Bold)
    }
}
